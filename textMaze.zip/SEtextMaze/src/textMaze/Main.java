package textMaze;

public class Main extends view2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		launch(args);

		
	}

}

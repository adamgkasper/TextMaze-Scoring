package textMaze;

import java.util.concurrent.TimeUnit;

public class stopWatch {
	
	private static long start;
	
	stopWatch()//constructor
	{
		start = System.currentTimeMillis();
	}
	
//	static stopWatch createStarted()
//	{
//		return now 
//		//provides a started stopwatch from convenience
//	}
	
	public void start()
	{
		//start the stopwatch
	}
	
	public void stop()
	{
		
	}
	
	public void pause()
	{
		
	}
	
	public void resume()
	{
		
	}
	
	public void reset()
	{
		
	}
	
	public static double getTime()
	{
		long now = System.currentTimeMillis();
		return ((now-start) / 1000);
	}
	
//	public String toString()
//	{
//		
//	}

}

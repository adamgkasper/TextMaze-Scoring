/*
Scene  
  |   
  V
Root Pane (Vbox for example)
  |                   |
  V                   V
Pane1                Pane2
*/

package textMaze;

import javafx.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class view2 extends Application implements EventHandler<ActionEvent>{

	
	private final String TITLE = "Text Maze V1.0";
	
	Stage window;
	Scene scene;
	Button enter;
	Button help;
	Button start;
	Button returnTime;
	Button End;
    long startTime = 0;
    long elapsedTime;
    long timeX;
    
	private final int SCENE_WIDTH  = 900;
	private final int SCENE_HEIGHT = 500;
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
						
	primaryStage.setTitle(	TITLE );
    
	//building enter button and text field
	enter = new Button("enter");
	help = new Button("help");
	start = new Button("start");
	returnTime = new Button("return time");
	End = new Button("End");
//	resume = new Button("resume timer");
//	reset = new Button("reset timer");
    
	
	
	TextField in  = new TextField(); 
	TextField in2 = new TextField();
	TextField in3 = new TextField();
	TextField in4 = new TextField();
	TextField in5 = new TextField();
	TextField in6 = new TextField();
	Label ceanterdText = new Label("I want this text centered");
	
    HBox hbox = new HBox(help, enter, start, returnTime, End);
    
   // hbox.getChildren().add(in);
   // hbox.getChildren().add(in2);
   
   // This class will handle the button events
    enter.setOnAction(this);
    start.setOnAction(this);
    returnTime.setOnAction(this);
    End.setOnAction(this);
    
    Scene scene = new Scene(hbox, 500, 250);
    primaryStage.setScene(scene);
    primaryStage.show();
}

//When button is clicked, handle() gets called
//Button click is an ActionEvent (also MouseEvents, TouchEvents, etc...)
@Override
public void handle(ActionEvent event) {
	int click =0; 
	if (event.getSource() == enter) {	
		while(click <= 10) {
		
    System.out.println("click");
	
	click++;
    		System.out.println(click);
		}//end of while
	}//end of if
	
	if(event.getSource() == start) {
		long total = 0;
		for(int i = 0; i < 10000000; i ++)
			total += i;
		
		long stopTime = System.currentTimeMillis();
		elapsedTime = (stopTime - startTime)/ 1000;
		
		System.out.println("start");
		}
	//Scoring system within the end button
	if(event.getSource() == returnTime) {
//		long total = 0;
//		for(int i = 0; i < 10000000; i ++)
//			total += i;
//		
		long stopTime = System.currentTimeMillis();
		long elapsedTime1 = (stopTime - startTime)/ 1000;
		timeX = elapsedTime1 - elapsedTime;
		System.out.println(timeX);
		
		if(timeX >= 0 && timeX <= 5)
		{
			System.out.println("Score: " + ((1000 - timeX) + 5000));
		
		}else if(timeX > 5 && timeX <= 10)
		{
			System.out.println("Score: " + ((1000 - timeX) + 4000));
		}else if(timeX > 10 && timeX <= 25)
		{
			System.out.println("Score: " + ((1000 - timeX) + 3500));
		}else if(timeX > 25 && timeX <= 50)
		{
			System.out.println("Score: " + ((1000 - timeX) + 3000));
		}else if(timeX > 50 && timeX <= 100)
		{
			System.out.println("Score: " + ((1000 - timeX) + 2500));
		}else if(timeX > 100 && timeX <= 150)
		{
			System.out.println("Score: " + ((1000 - timeX) + 2000));
		}else if(timeX > 150 && timeX <= 200)
		{
			System.out.println("Score: " + ((1000 - timeX) + 1000));
		}else if(timeX > 200)
		{
			System.out.println("score: " + (1000 - timeX));
		}
	}
	
	if(event.getSource() == End) {
		System.out.println("Game finished.");
	}
	
}//end of handle
}//closing bracket